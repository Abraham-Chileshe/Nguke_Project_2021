<?php
    $host = 'localhost';
    $user =  'root';
    $pwd = '';
    $db = 'nguke';

    $con = mysqli_connect($host, $user, $pwd, $db);




?>